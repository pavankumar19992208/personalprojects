export default {
  plugins: {
    "@tailwindcss/postcss": {}, // Changed from 'tailwindcss'
    autoprefixer: {},
  },
};
